# Projects

Reference image: `screens/02-projects.png`

Reusable regeneration prompt, consolidated from this conversation; not a verbatim tool-call transcript. Attach the reference PNG before using.

```text
Create a high-fidelity desktop UI mockup for Mimin, matching the supplied reference image. Output one complete straight-on landscape screenshot, approximately 1600 × 1000, without a device frame or presentation captions.

Design system: minimal dark zinc monochrome. Uniform canvas #141416, dock #1B1B1E, flat surfaces #202023, fields #151517, faint borders #2C2C30, primary text #ECECEE, secondary text #A1A1AA. Use soft diffused exterior drop shadows only. No bevels, inset lighting, sculpted depth, glossy textures, decorative gradients, hero sculptures or colored accents. Render crisp readable sans-serif typography and consistent thin line icons.

Shell: narrow floating left dock, small m monogram, plus, chat, projects, skills; gear and F avatar at bottom. Main mimin wordmark and quiet appearance control. Highlight only the relevant destination. Use restrained rounded corners, comfortable spacing and clear hierarchy. Settings use a centered modal with a fixed category sidebar, close control and dimmed app background.

Match the supplied screen content and functionality. Reduce visible clutter through tabs, disclosures and overflow menus. Keep primary actions obvious, secondary actions quiet. Never show real API keys or fabricate additional data. Refer to the paired PNG for composition; text instructions take precedence over incidental generated-image artifacts.

Screen brief:
Folder icon selected. Heading Projects, subtitle 'A space for work you return to.', one New project button, 3 projects count, search and grid/list controls. Three equal flat cards: Kuliah — Coursework, notes, and everything worth learning. — 1 file, 11 chats, Sep 26; Metopen — Research on model routing and agent efficiency. — 0 files, 1 chat, Sep 22; Mimin Coding Agent — Building a lightweight multi-agent coding system. — 0 files, 0 chats, Sep 22. Consistent padding and footer alignment, line folder icons and small open arrows. Remove duplicate create card.
```
